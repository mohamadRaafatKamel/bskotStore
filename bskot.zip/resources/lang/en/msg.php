<?php

return [
    // front.include.header
    'Menu'=>'Menu',
    'search'=>'Search',
    'Branches'=>'Branches',
    'Order Status'=>'Order Status',

    // front.include.toppage
    'Baskotii'=>'Baskotii',
    'Hand made with love'=>'Hand made with love',

    // front.home
    'Search'=>'Search',
    'StartOrder'=>'Start Order',
    'Revieworder'=>'Review order',
    'AED'=>'AED',

    // front.delivery
    'Order Mode'=>'Order Mode',
    'Name'=>'Name',
    'delivery'=>'Delivery',
    'Phone'=>'Phone',
    'PhonePlaceholder'=>'Add phone without +971',
    'Location'=>'Location',
    'Next'=>'Next',
    'Edit'=>'Edit',

    //front.view
    'Price'=>'Price',
    'Add Instructions'=>'Add Instructions (Option)',
    'Add to Order'=>'Add to Order',

    //front.cart
    'Review Order'=>'Review Order',
    'emptyCart1'=>'Your bag is empty',
    'emptyCart2'=>'Browse menu and add items to your order to proceed',
    'Delivery Info'=>'Delivery Info',
    'day'=>'day',
    'Order Items'=>'Order Items',
    'Remove'=>'Remove',
    'Apply'=>'Apply',
    'Enter Code'=>'Enter Code',
    'check Out'=>'check Out',
    'Total'=>'Total',
    'discount'=>'Discount',
    'price'=>'Price',
    'CodeNotValid'=>'Code Not Valid',
    'ThankYoucodeadded'=>'Thank You code added',
    'removeCode'=>'Code removed',

    //front.adress
    'fulladress'=>'Add full adress',

    //front.otp
    'Order Look Up'=>'Order Look Up',
    'otpmessages'=>'OTP code can be found in SMS messages, after placing an order.',
    'OTP Code'=>'OTP Code',
    'confirm OTP code'=>'confirm OTP code',
    'thank for confirm'=>'thank for confirm',
    'Not same OTP code'=>'Not same OTP code',

    //front.credit
    'Payment Method'=>'Payment Method',
    'cash'=>'cash',
    'Payment'=>'Payment',

    //front.ThanksPage
    'Thanks Page'=>'Thanks Page',
    'ThanksPage1'=>'Thank you for Payment',
    'ThanksPage2'=>'SMS massage send for your phone ',
    'Back'=>'Back',

    //front.Check Order
    'Order Look Up2'=>'Order Look Up',
    'Check Order'=>'Check Order',
    'Check Order2'=>'Order code can be found in SMS messages, after placing an order.',
    'Order Code'=>'Order Code',
    'check'=>'check',
    'Not Found'=>'Not Found',

    //front.Branches
    'Branches1'=>'Branche Open Soon',

    //front.search
    'Cancel'=>'Cancel',
    'searchPage2'=>'Type in what you are looking for',
    'Find products'=>'Find products',

];

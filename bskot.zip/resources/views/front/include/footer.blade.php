<footer class="page-footer text-center font-small mt-4" style="background-color: rgba(0, 0, 0, 0.5);">
    <!--Copyright-->
    <div class="footer-copyright py-3">
        © 2020 Copyright: <a href="https://www.baskotii.ae"> Baskotii </a>
        <!--<br/>-->
        <!--Power By: <a href="https://www.devmrm.com" target="_blank"> DevMRM </a>-->
    </div>
    <!--/.Copyright-->
</footer>
<!--/.Footer-->

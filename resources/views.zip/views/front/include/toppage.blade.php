<div class="view" style="background-image: url('{{asset('assets/front/img/topImg.jpg')}}');
    background-repeat: no-repeat; bottom: 25px; background-size: cover;">

    <!-- Mask & flexbox options-->
    <div class="mask rgba-black-light d-flex justify-content-center align-items-center">

        <!-- Contenttop-nav-collapse -->
        <div class="text-center white-text mx-5 wow fadeIn">

            <!--Img-->
        </div>
        <!-- Content -->

    </div>
    <!-- Mask & flexbox options-->

</div>
<!-- Full Page Intro -->
<!--  logo-->
<div class="sec-nav">
    <img src="{{asset('assets/front/img/logo.jpg')}}"/>
    <div>
        <h1>DietCare</h1>
        <h2>My Life Concept</h2>
    </div>
</div>

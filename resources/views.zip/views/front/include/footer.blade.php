<footer class="page-footer text-center font-small mt-4 wow fadeIn">
    <!--Copyright-->
    <div class="footer-copyright py-3">
        © 2020 Copyright:
        <a href="https://www.devmrm.com" target="_blank"> DevMRM </a>
    </div>
    <!--/.Copyright-->
</footer>
<!--/.Footer-->
